﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LinqAssignment
{
    class Orders
    {
        public int Order_id { get; set; }
        public string item_name { get; set; }
        public DateTime Orderdate { get; set; }
        public int Quantity { get; set; }

        public Orders(int id, string Name, DateTime orderdate, int quantity)
        {
            Order_id = id;
            item_name = Name;
            Orderdate = orderdate;
            Quantity = quantity;

        }
    }
    internal class Assignment4
    {
          
        static void Main()
        {
            List<Order> orders = new List<Order>()
            {
                 new Order (1,"Wheat",DateTime.Parse("2/23/2022"),10),
                 new Order (1,"Wheat",DateTime.Parse("2/23/2022"),40),
                new Order (2,"Rice",DateTime.Parse("6/23/2022"),20),
                new Order (2,"Rice",DateTime.Parse("6/23/2022"),70),
                new Order (2,"Rice",DateTime.Parse("6/23/2022"),80),
                new Order (3,"Shoes",DateTime.Parse("7/23/2022"),30)
            };
            var orderedByMonth = orders.OrderByDescending(o => o.Orderdate).GroupBy(o => o.Orderdate.Month);
            foreach (var group in orderedByMonth)
            {
                Console.WriteLine($"Month:{group.Key}");

                foreach (var ord in group)
                {
                    Console.WriteLine($"Orderid:{ord.Order_id}, item_name:{ord.item_name},Orderdate:{ord.Orderdate},Quantity:{ord.Quantity}");
                }
            }
        }
    }
}
