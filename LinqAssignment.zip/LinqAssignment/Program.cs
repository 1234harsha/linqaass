﻿namespace LinqAssignment
{
    internal class Program
    {
        //1.Given an array of numbers. Find  the cube of the numbers that are greater than 100 but less than 1000 using LINQ.
        static void Main(string[] args)
        {
            {
                int[] arr = { 4, 16, 1, 8, 9, 13, 7, 5, 12 };
                var cube = from x in arr
                           let y = x * x * x
                          where y > 100 && y < 1000
                          select y;
                foreach (var item in cube)
                {
                    Console.WriteLine(item);

                }
            }
        }
    }
}
