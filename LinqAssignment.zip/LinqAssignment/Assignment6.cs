﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LinqAssignment
{

    internal class Assignment6
    {
        public static void Main()
        {
            List<Order> orders = new List<Order>()
            {
                 new Order (1,"Paste",DateTime.Parse("2/23/2022"),10),
                 new Order (1,"Paste",DateTime.Parse("2/23/2022"),40),
                new Order (2,"Soap",DateTime.Parse("6/23/2022"),20),
                new Order (2,"Soap",DateTime.Parse("6/23/2022"),70),
                new Order (2,"Soap",DateTime.Parse("6/23/2022"),80),
                new Order (3,"Shoes",DateTime.Parse("7/23/2022"),30)
            };
            List<Item> items = new List<Item>()
                {
                    new Item("Paste",30),
                    new Item("Soap",40),
                    new Item("Shoes",300)
                };

            var result = from s in orders
                         join e in items
                         on s.item_name equals e.item_name
                         select new { id = s.Order_id, name = s.item_name, dt = s.Orderdate, price = (s.Quantity * e.price) };

            foreach (var item in result)
            {
                Console.WriteLine($"ID:{item.id} Name :{item.name} Orderdate :{item.dt} totalPrice:{item.price}");
            }
            var orderedByMonth = orders.OrderByDescending(o => o.Orderdate).GroupBy(o => o.Orderdate.Month);


            foreach (var item in orderedByMonth)
            {
                Console.WriteLine($"Month:{item.Key}");

                foreach (var ord in item)
                {
                    Console.WriteLine($"Orderid:{ord.Order_id}, item_name:{ord.item_name},Orderdate:{ord.Orderdate},Quantity:{ord.Quantity}");
                }


            }
        }
    }
}

