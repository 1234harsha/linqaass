﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LinqAssignment
{
    internal class Assignment2
    {
        class Player
        {

            public Player(string name, string country)
            {
                Name = name;
                Country = country;

            }
            public string Name { get; set; }
            public string Country { get; set; }
        }


        static void Main()
        {
            List<Player> list1 = new List<Player>()
            {
                new Player("Player1", "India"),
                new Player("Player2", "US"),
                new Player("Player5", "China"),
            };
            List<Player> list2 = new List<Player>()
            {
                new Player("Player3", "India"),
                new Player("Player4","UK"),
                new Player("Player6","Australia"),
            };
            var result = from l1 in list1
                         from l2 in list2
                         where l1.Country != l2.Country
                         select new { op = l1.Name, op1 = l2.Name };
            foreach (var p in result)
                Console.WriteLine($"{p.op}*{p.op1}");

        }
    }
}
