﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LinqAssignment
{
    class Item
    {
        public Item(string item_name, int price)
        {
            this.item_name = item_name;
            this.price = price;
        }

        public string item_name { get; set; }
        public int price { get; set; }
    }
    class OrderDetails
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public DateTime Date { get; set; }
        public int TotalPrice { get; set; }
    }

    internal class Assignment5
    {
        public static void Main()
        {
            List<Order> orders = new List<Order>()
            {
                new Order(1, "Paste", DateTime.Parse("2/23/2022"), 10),
                new Order(1, "Paste", DateTime.Parse("2/23/2022"), 40),
                new Order(2, "Soap", DateTime.Parse("6/23/2022"), 20),
                new Order(2, "Soap", DateTime.Parse("6/23/2022"), 70),
                new Order(2, "Soap", DateTime.Parse("6/23/2022"), 80),
                new Order(3, "Shoes", DateTime.Parse("7/23/2022"), 30)
            };

            List<Item> items = new List<Item>()
            {
                new Item("Paste", 30),
                new Item("Soap", 40),
                new Item("Shoes", 300)
            };

            List<OrderDetails> result = (from s in orders
                                         join e in items
                                         on s.item_name equals e.item_name
                                         select new OrderDetails
                                         {
                                             Id = s.Order_id,
                                             Name = s.item_name,
                                             Date = s.Orderdate,
                                             TotalPrice = (s.Quantity * e.price)
                                         }).ToList();

            foreach (var item in result)
            {
                Console.WriteLine($"ID:{item.Id} Name :{item.Name} Orderdate :{item.Date} totalPrice:{item.TotalPrice}");
            }

            var orderedByMonth = orders.OrderByDescending(o => o.Orderdate).GroupBy(o => o.Orderdate.Month);

            foreach (var item in orderedByMonth)
            {
                Console.WriteLine($"Month:{item.Key}");

                foreach (var ord in item)
                {
                    Console.WriteLine($"Orderid:{ord.Order_id}, item_name:{ord.item_name},Orderdate:{ord.Orderdate},Quantity:{ord.Quantity}");
                }
            }
        }
    }
}
